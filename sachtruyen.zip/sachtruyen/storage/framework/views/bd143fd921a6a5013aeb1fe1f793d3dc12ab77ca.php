

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-12 col-md-8" style="    width: 100%;"> <!-- Thay col-md-8 thành col-12 col-md-8 -->
            <div class="card">
                <div class="card-header">Liệt kê truyện</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <!-- Thêm wrapper cho table để scroll ngang trên mobile -->
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Tên truyện</th>
                                    <th scope="col" class="d-none d-md-table-cell">Hình ảnh</th> <!-- Ẩn trên mobile -->
                                    <th scope="col" class="d-none d-lg-table-cell">Slug truyện</th> <!-- Ẩn trên mobile nhỏ -->
                                    <th scope="col" class="d-none d-md-table-cell">Tóm tắt</th> <!-- Ẩn trên mobile -->
                                    <th scope="col">Danh mục</th>
                                    <th scope="col">Kích hoạt</th>
                                    <th scope="col">Quản lý</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $list_truyen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $truyen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row"><?php echo e($key); ?></th>
                                        <td><?php echo e($truyen->tentruyen); ?></td>
                                        <td class="d-none d-md-table-cell">
                                            <img src="<?php echo e(asset('public/uploads/truyen/'.$truyen->hinhanh)); ?>" 
                                                 class="img-fluid" 
                                                 style="max-height: 200px; max-width: 150px;" 
                                                 alt="<?php echo e($truyen->tentruyen); ?>">
                                        </td>
                                        <td class="d-none d-lg-table-cell"><?php echo e($truyen->slug_truyen); ?></td>
                                        <td class="d-none d-md-table-cell"><?php echo e($truyen->tomtat); ?></td>
                                        <td><?php echo e($truyen->danhmuctruyen->tendanhmuc); ?></td>
                                        <td>
                                            <?php if($truyen->kichhoat == 0): ?>
                                                <span class="text text-success">Kích hoạt</span>
                                            <?php else: ?>
                                                <span class="text text-danger">Không kích hoạt</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <div class="d-flex flex-column flex-md-row gap-2">
                                                <a href="<?php echo e(route('truyen.edit', [$truyen->id])); ?>" 
                                                   class="btn btn-primary btn-sm">Edit</a>
                                                <form action="<?php echo e(route('truyen.destroy', [$truyen->id])); ?>" 
                                                      method="post" 
                                                      class="d-inline">
                                                    <?php echo method_field('DELETE'); ?>
                                                    <?php echo csrf_field(); ?>
                                                    <button onclick="return confirm('Bạn muốn xóa truyện này không ?')" 
                                                            class="btn btn-danger btn-sm">Delete</button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    /* Thêm CSS tùy chỉnh nếu cần */
    @media (max-width: 768px) {
        .card-header {
            font-size: 1.1rem;
        }
        
        .btn-sm {
            width: 100%;
        }
    }
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\projects\sachtruyen\resources\views/admincp/truyen/index.blade.php ENDPATH**/ ?>