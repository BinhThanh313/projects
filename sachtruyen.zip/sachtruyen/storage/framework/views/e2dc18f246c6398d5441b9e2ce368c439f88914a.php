<?php $__env->startSection('content'); ?>

<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8" style="    width: 100%;">
            <div class="card">
                <div class="card-header">Quản lý</div>
            
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <h3>Danh sách truyện</h3>
                    <?php if(isset($truyen) && $truyen->count() > 0): ?>
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Tên truyện</th>
                                    <th>Tác giả</th>
                                    <th>Danh mục truyện</th>
                                    <th>Số chapter</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $truyen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($item->tentruyen); ?></td>
                                    <td><?php echo e($item->tacgia ?? 'Chưa có tác giả'); ?></td>
                                    <td><?php echo e($item->danhmuctruyen->tendanhmuc ?? 'Chưa có danh mục'); ?></td>
                                    <td><?php echo e($item->chapters_count); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <p>Không có truyện nào để hiển thị.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\projects\sachtruyen\resources\views/home.blade.php ENDPATH**/ ?>