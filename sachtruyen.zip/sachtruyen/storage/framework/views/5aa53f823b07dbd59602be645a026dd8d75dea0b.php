

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Cập nhật chapter truyện</div>
                
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                
                    <form method="POST" action="<?php echo e(route('chapter.update', [$chapter -> id])); ?>">
                        <?php echo method_field('PUT'); ?>
                    <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Tên chapter</label>
                            <input type="text" class="form-control" value="<?php echo e($chapter -> tieude); ?>" onkeyup="ChangeToSlug()"  name = "tieude" id="slug" aria-describedby="emailHelp" placeholder="Tên danh mục">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Slug truyện</label>
                            <input type="text" class="form-control" value="<?php echo e($chapter -> slug_chapter); ?>" name = "slug_chapter" id="convert_slug" aria-describedby="emailHelp" placeholder="Slug danh mục">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Tóm tắt truyện</label>
                            <input type="text" class="form-control" value="<?php echo e($chapter -> tomtat); ?>" name = "tomtat" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Mô tả danh mục">                                          
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Nội dung</label>
                            <textarea name="noidung" id="noidung_chapter" class="form-control" rows="5" style="resize: none"></textarea>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Thuộc truyện</label>
                            <select name="truyen_id" class="custom-select" style="display: block; width: 100%; border-radius: 6px; border: 1px solid rgba(0, 0, 0, 0.2); height: 36px;">
                                <?php $__currentLoopData = $truyen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php echo e($chapter->truyen_id == $value->id ? 'selected' : ''); ?> value="<?php echo e($value->id); ?>"><?php echo e($value->tentruyen); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Kích hoạt</label>
                            <select name="kichhoat" class="custom-select" style="display: block; width: 100%; border-radius: 6px; border: 1px solid rgba(0, 0, 0, 0.2); height: 36px;">
                                <?php if($chapter->kichhoat == 0): ?>
                                <option <?php echo e($chapter->kichhoat == 0 ? 'selected' : ''); ?> value="0">Kích hoạt</option>
                                <option <?php echo e($chapter->kichhoat == 1 ? 'selected' : ''); ?> value="1">Không kích hoạt</option>
                                <?php else: ?>
                                <option value="0">Kích hoạt</option>
                                <option selected value="1">Không kích hoạt</option>
                                <?php endif; ?>
                                
                            </select>

                        </div>
                        <button type="submit" name = "themdanhmuc" class="btn btn-primary" style="margin-top: 16px; width: 100%;">Cập nhật</button>
                    </form>
                    
                    

                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\projects\sachtruyen\resources\views/admincp/chapter/edit.blade.php ENDPATH**/ ?>